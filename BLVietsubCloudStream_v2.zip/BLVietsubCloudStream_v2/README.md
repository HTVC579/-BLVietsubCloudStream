# BLVietsub CloudStream

CloudStream 3 provider project for BLVietsub.

This project is based on the current reCloudStream TestPlugins repository structure.
The official template currently uses Android Gradle Plugin 8.7.3, Kotlin 2.1.0,
CloudStream Gradle plugin `-SNAPSHOT`, and builds with `./gradlew <Plugin>:make`.

The GitHub Actions workflow in this project uses Gradle 8.9 directly, so a Gradle
wrapper JAR is not required in the uploaded source repository.

The provider reads the BLVietsub movie page and attempts to collect episode/server
links exposed by the page. It delegates supported hosts to CloudStream extractors
and has a basic direct HLS/MP4 fallback.

Playback depends on the current player implementation and availability of the
linked video hosts. This project does not bypass DRM or access controls.
