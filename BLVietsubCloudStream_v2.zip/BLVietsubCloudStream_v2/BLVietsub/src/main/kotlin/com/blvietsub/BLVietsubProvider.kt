package com.blvietsub

import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import org.jsoup.nodes.Document
import java.net.URI
import java.net.URLEncoder

class BLVietsubProvider : MainAPI() {
    override var mainUrl = "https://blvietsub.com"
    override var name = "BLVietsub"
    override var lang = "vi"
    override val supportedTypes = setOf(TvType.TvSeries, TvType.Movie)

    private val videoHosts = setOf(
        "ssplay.net", "www.ssplay.net",
        "dailymotion.com", "www.dailymotion.com",
        "player.abyssplayer.com"
    )

    override suspend fun search(query: String): List<SearchResponse> {
        val url = "$mainUrl/?s=${URLEncoder.encode(query, "UTF-8")}"
        val doc = app.get(url).document()
        return doc.select("a[href]").mapNotNull { a ->
            val href = a.absUrl("href")
            val title = a.text().trim()
            if (!href.startsWith(mainUrl) || title.length < 2) return@mapNotNull null
            if (href == mainUrl || href == "$mainUrl/") return@mapNotNull null
            val poster = a.selectFirst("img")?.let { img ->
                img.absUrl("src").ifBlank { img.absUrl("data-src") }
            }
            newTvSeriesSearchResponse(title, href) { posterUrl = poster }
        }.distinctBy { it.url }.take(30)
    }

    override suspend fun load(url: String): LoadResponse? {
        val doc = app.get(url).document()
        val title = doc.selectFirst("h1")?.text()?.trim()
            ?: doc.selectFirst("meta[property=og:title]")?.attr("content")?.trim()
            ?: return null
        val poster = doc.selectFirst("meta[property=og:image]")?.attr("content")
        val plot = doc.selectFirst("meta[property=og:description]")?.attr("content")
        val year = Regex("\\b(?:19|20)\\d{2}\\b").find(doc.text())?.value?.toIntOrNull()
        val episodes = extractEpisodes(doc)
        return newTvSeriesLoadResponse(title, url, TvType.TvSeries, episodes) {
            posterUrl = poster
            this.plot = plot
            this.year = year
        }
    }

    private fun extractEpisodes(doc: Document): List<Episode> {
        val out = mutableListOf<Episode>()
        doc.select("a[href]").forEach { a ->
            val href = a.absUrl("href").trim()
            if (href.isBlank()) return@forEach
            val host = runCatching { URI(href).host?.lowercase() }.getOrNull() ?: return@forEach
            if (videoHosts.none { host == it || host.endsWith(".$it") }) return@forEach
            val text = a.text().trim()
            val number = Regex("(?:Tập|Tap|Episode|EP)?\\s*[-.]?\\s*(\\d{1,3})", RegexOption.IGNORE_CASE)
                .find(text)?.groupValues?.getOrNull(1)?.toIntOrNull()
                ?: Regex("(?:episode|ep|tap)[-_ ]?(\\d{1,3})", RegexOption.IGNORE_CASE)
                    .find(href)?.groupValues?.getOrNull(1)?.toIntOrNull()
                ?: return@forEach
            val server = when {
                host.contains("dailymotion") -> "DL"
                host.contains("ssplay") -> "SS"
                host.contains("abyssplayer") -> "HX"
                else -> host
            }
            out += newEpisode(href) {
                name = "$server • Tập $number"
                season = 1
                episode = number
            }
        }
        return out.distinctBy { "${it.episode}|${it.data}" }
            .sortedWith(compareBy<Episode> { it.episode ?: Int.MAX_VALUE }.thenBy { it.name })
    }

    override suspend fun loadLinks(
        data: String,
        isCasting: Boolean,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        if (data.isBlank()) return false
        var loaded = false
        runCatching {
            loaded = loadExtractor(data, null, subtitleCallback, callback) || loaded
        }
        // Some players expose direct HLS/MP4 in their HTML. This fallback only
        // consumes ordinary media URLs already present in the page.
        runCatching {
            val html = app.get(data).text
            val regexes = listOf(
                Regex("[\\\"']([^\\\"']+\\.m3u8(?:\\?[^\\\"']*)?)[\\\"']", RegexOption.IGNORE_CASE),
                Regex("[\\\"']([^\\\"']+\\.mp4(?:\\?[^\\\"']*)?)[\\\"']", RegexOption.IGNORE_CASE)
            )
            val streams = linkedSetOf<String>()
            regexes.forEach { regex ->
                regex.findAll(html).forEach { match ->
                    val stream = match.groupValues[1].replace("\\/", "/")
                    if (stream.startsWith("http")) streams += stream
                }
            }
            streams.forEach { stream ->
                callback(
                    newExtractorLink(
                        source = name,
                        name = "BLVietsub",
                        url = stream,
                        type = if (stream.contains(".m3u8", true)) ExtractorLinkType.M3U8 else ExtractorLinkType.VIDEO
                    ) { referer = data }
                )
                loaded = true
            }
        }
        return loaded
    }
}
