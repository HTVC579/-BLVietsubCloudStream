package com.blvietsub

import android.content.Context
import com.lagradost.cloudstream3.plugins.CloudstreamPlugin
import com.lagradost.cloudstream3.plugins.Plugin

@CloudstreamPlugin
class BLVietsubPlugin : Plugin() {
    override fun load(context: Context) {
        registerMainAPI(BLVietsubProvider())
    }
}
