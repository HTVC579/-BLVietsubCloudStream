version = 1

cloudstream {
    description = "BLVietsub provider"
    authors = listOf("Personal use")
    status = 1
    tvTypes = listOf("TvSeries", "Movie")
    language = "vi"
    iconUrl = "https://blvietsub.com/wp-content/uploads/2025/01/cropped-logo.png"
}
